const express = require("express");
const path = require("path");
const ejs = require('ejs');
const morgan = require('morgan')

const fileUpload = require("express-fileupload");
const mongoose = require("mongoose");
const Question = require("./models/questions").Question;

const app = express();
const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://127.0.0.1:27017/BoardGame'; // Replace "mydb" with your database name
//const options = {
  //useNewUrlParser: true,
  //useUnifiedTopology: true,
  //auth: {
    //user: 'username',
    //password: 'password'
  //}
//};
mongoose
.connect(url,{
useNewUrlParser: true,
//useCreateIndex: true,
useUnifiedTopology: true
}).then(() => console.log('DB Connected'));
//MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function(err, client) {
  //if (err) {
    //console.error('Error connecting to database:', err);
    //return;
  //}
  //console.log('Connected to database');
  // Perform database operations here
  //app.use(BoardGame());
//});
// CONNECTING TO MONGOOSE xZY3Oq00LHVK8otJ   mongodb+srv://nags1234:<password>@cluster0.eboj25u.mongodb.net/test
// const connectDB = 'mongodb://127.0.0.1/nagsg';
//const connectDB ="mongodb://127.0.0.1:27017/BoardGame";
//const url = 'mongodb://127.0.0.1:27017/BoardGame'

//const connectDB ="mongodb+srv://nags1234:zipziproute123@cluster0.eboj25u.mongodb.net/nags12345";
//const connectDB ="";
//mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }).then((res) => {
  //  console.log("MongoDb Connected Successfully!")
//}).catch((err) => {
  //  console.log("Error=> MongoDb error Connection!")
//})

 //app.use(BoardGame());

app.use(fileUpload({
    createParentPath: true
}))
app.get('/match', (req, res) => {
    res.render('match.ejs');
});
app.get('/', (req, res) => {
    res.render('home.ejs');
});
app.get('/conclusion', (req, res) => {
    res.render('conclusion.ejs');
});


app.use(express.json());
app.use(express.urlencoded({ extended: true }))
app.use(morgan('dev'))

app.use(express.static(__dirname + "/public"));

app.set('views', path.join(__dirname, './views'))
app.set('view engine', ejs);

app.get("/index", (req, res) => {
    Question.find().then((data) => {
        res.render("index.ejs", { data:JSON.stringify(data) })
    }).catch(err => console.log("err", err))

})

app.get("/admin", (req, res) => {
    res.render("admin.ejs")
})

app.get("/home", (req, res) => {
    res.render("home.ejs")
})


app.post("/save2", (req, res)=>{
    const newQuestion = new Question({
        _id: new mongoose.Types.ObjectId(),
        title: req.body.title,
        question: req.body.question,
        answers: [{
            text: req.body.mcq1,
            
        },
        {
            text: req.body.mcq2,
           
        },
        {
            text: req.body.mcq3,
            correct: true,
            
        },
        {
            text: req.body.mcq4,
            
        }
        ]
    })

    newQuestion.save().then((savedDoc) => {
        console.log(savedDoc)
        res.status(200).json({
            message: "New MCQ Added Successfully!"
        })
    }).catch((err) => {
        console.log(err)
    })
})


app.post('/save', async (req, res) => {
    console.log("body", req.body)
    try {
        if (!req.files) {
            res.send({
                status: false,
                message: 'No file uploaded'
            });
        } else {
            let avatar = req.files.imageFile;
            console.log(avatar)
            let savePath = avatar.name;
            let uploadPath = path.resolve(__dirname, './public/uploaded', avatar.name)
            // avatar.mv('./public/uploaded/' + avatar.name);
            avatar.mv(uploadPath, (err) => {
                if (err) {
                    console.log("err", err)
                    return res.status(500).send(err);
                }
                // FILE UPLOADED

               let answers =  [{
                text: req.body.mcq1,
                correct:false,
                reason: req.body.reasonForMcq1
            },
            {
                text: req.body.mcq2,
                correct:false,
                reason: req.body.reasonForMcq2
            },
            {
                text: req.body.mcq3,
                correct: false,
                reason: req.body.reasonForMcq3
            },
            {
                text: req.body.mcq4,
                correct:false,
                reason: req.body.reasonForMcq4

            }
            ]
            answers[parseInt(req.body.answer)].correct = true;

                const newQuestion = new Question({
                    _id: new mongoose.Types.ObjectId(),
                    imgUrl:savePath,
                    heading:"mcq",
                    title: req.body.title,
                    question: req.body.question,
                    answers:answers
                })

                newQuestion.save().then((savedDoc) => {
                    console.log(savedDoc)
                    res.status(200).json({
                        message: "New MCQ Added Successfully!"
                    })
                }).catch((err) => {
                    console.log(err)
                })


            })



        }
    } catch (err) {
        console.log("err catch", err)
        res.status(500).send(err);
    }
});

app.post('/save2q', async (req, res) => {
    console.log("body", req.body)
    try {
        if (!req.files) {
            res.send({
                status: false,
                message: 'No file uploaded'
            });
        } else {
            let avatar = req.files.imageFile;
            console.log(avatar)
            let savePath = avatar.name;
            let uploadPath = path.resolve(__dirname, './public/uploaded', avatar.name)
            // avatar.mv('./public/uploaded/' + avatar.name);
            avatar.mv(uploadPath, (err) => {
                if (err) {
                    console.log("err", err)
                    return res.status(500).send(err);
                }
                // FILE UPLOADED

               let answers =  [{
                text: req.body.mcq1,
                correct:false,
                reason: req.body.reasonForMcq1
            },
            {
                text: req.body.mcq2,
                correct:false,
                reason: req.body.reasonForMcq2
            },
            
            ]
            answers[parseInt(req.body.answer)].correct = true;

                const newQuestion = new Question({
                    _id: new mongoose.Types.ObjectId(),
                    imgUrl:savePath,
                    heading:"yes/no",
                    title: req.body.title,
                    question: req.body.question,
                    answers:answers
                })

                newQuestion.save().then((savedDoc) => {
                    console.log(savedDoc)
                    res.status(200).json({
                        message: "New 2qMCQ Added Successfully!"
                    })
                }).catch((err) => {
                    console.log(err)
                })


            })



        }
    } catch (err) {
        console.log("err catch", err)
        res.status(500).send(err);
    }
});







const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running at port ${port}`)
})

